package com.alicyu.springcloud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author Alicyu
 * @classname ConfigClient_3355_StartSpringCloudA
 * @description TODO
 * @date 2019/9/6 16:27
 */
@SpringBootApplication
public class ConfigClient_3355_StartSpringCloudApp {
    public static void main(String[] args) {
        SpringApplication.run(ConfigClient_3355_StartSpringCloudApp.class,args);
    }
}
