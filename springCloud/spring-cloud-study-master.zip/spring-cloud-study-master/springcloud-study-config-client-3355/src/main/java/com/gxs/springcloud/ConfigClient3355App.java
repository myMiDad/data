package com.gxs.springcloud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author GongXings
 * @createTime 31 19:14
 * @description
 */
@SpringBootApplication
public class ConfigClient3355App {
    public static void main(String[] args) {
        SpringApplication.run(ConfigClient3355App.class,args);
    }
}